# Fala Fono para iOS

Versão iOS do Fala Fono PC 0.2.0, com implantação mínima no iOS 18. O projeto reutiliza a interface e os módulos web fornecidos no pacote original e os abre dentro de um contêiner nativo WKWebView.

## O que está incluído

- Tela inicial com o Papagaíto e fala em português brasileiro, usando a voz do iOS.
- Minha Casa e Animais e seus Sons, com os modelos 3D procedurais do projeto e atividades de associação.
- Editor e biblioteca de cards: criar, editar, excluir, escolher imagens, importar/exportar JSON e imprimir ou salvar como PDF pelo iOS.
- Área Clínica com PIN, cofre local AES-GCM-256 e PBKDF2-HMAC-SHA256 (150.000 iterações), pacientes, observações factuais, sessões, bloqueio por inatividade e backup cifrado.
- Configurações de voz, volume, animação, texto e visualização 3D.
- Dados ficam no contêiner do app; o projeto não adiciona telemetria nem sincronização remota.

As preferências e os cards usam o armazenamento local do WKWebView e não são cifrados pelo app, como na versão PC. Os dados clínicos são cifrados antes de salvar. O conteúdo clínico não recebe pontuações nem gera diagnósticos automáticos. Antes de usar com pacientes, a clínica ainda precisa aprovar identidade do controlador, finalidades e bases legais, aviso de privacidade, retenção e descarte. O app não substitui essa revisão.

Para levar dados do PC ao iPhone, exporte o backup cifrado na Área Clínica do PC e restaure o JSON no iOS com o mesmo PIN. Os cards podem ser transferidos pelo JSON de exportação/importação. As preferências não são migradas automaticamente.

## Limite do Merge Cube

O pacote PC informa que não possui rastreador de Merge Cube. O iOS mantém a tela informativa e pode mostrar a câmera quando solicitada, mas não reconhece o cubo nem simula detecção. A atividade 3D convencional continua disponível.

Os modelos 3D são as formas procedurais provisórias do pacote PC. A voz é sintetizada pelo iOS; não há gravação de voz do paciente.

## Gerar o IPA no GitHub Actions

O workflow manual incluído compila o projeto num runner macOS hospedado pelo GitHub e gera FalaFono-unsigned.ipa, sem exigir Mac local, conta Apple Developer, certificado ou perfil de provisionamento.

1. Use um repositório GitHub (privado recomendado) e envie o conteúdo desta pasta para a raiz do repositório.
2. Abra Actions, escolha Build unsigned iOS IPA e clique em Run workflow.
3. Quando a execução terminar, baixe o artefato FalaFono-IPA-sem-assinatura.

O IPA sem assinatura é um pacote de build para arquivamento e inspeção. O iOS não permite instalá-lo num iPhone e ele não pode ser enviado à App Store. Para instalar ou distribuir, é necessário assinar o app e incluir um perfil de provisionamento apropriado; a Apple explica os requisitos no [guia oficial de distribuição para dispositivos registrados](https://developer.apple.com/documentation/xcode/distributing-your-app-to-registered-devices). O runner macOS hospedado é listado na [documentação do GitHub Actions](https://docs.github.com/en/actions/reference/runners/github-hosted-runners).

## Abrir no Xcode

1. Em um Mac com Xcode, abra FalaFono.xcodeproj.
2. Selecione um simulador ou iPhone com iOS 18 ou posterior.
3. Para instalar em um dispositivo, configure uma equipe de assinatura e um perfil de provisionamento no Xcode.

