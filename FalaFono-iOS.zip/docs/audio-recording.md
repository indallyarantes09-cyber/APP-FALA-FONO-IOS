# Gravação dos áudios

Os arquivos abaixo substituem a voz sintética automaticamente. Grave em português brasileiro, com fala clara, ritmo natural e pausas curtas. Exportar MP3 mono, 44,1 kHz, volume normalizado sem música ao fundo.

| Pasta/arquivo | Conteúdo sugerido |
| --- | --- |
| assets/audio/words/sofa.mp3 | Sofá. |
| assets/audio/words/televisao.mp3 | Televisão. |
| assets/audio/words/mesa.mp3 | Mesa. |
| assets/audio/words/cadeira.mp3 | Cadeira. |
| assets/audio/words/geladeira.mp3 | Geladeira. |
| assets/audio/words/fogao.mp3 | Fogão. |
| assets/audio/words/cama.mp3 | Cama. |
| assets/audio/words/travesseiro.mp3 | Travesseiro. |
| assets/audio/words/chuveiro.mp3 | Chuveiro. |
| assets/audio/words/espelho.mp3 | Espelho. |
| assets/audio/animals/cachorro.mp3 | Cachorro! Au au! |
| assets/audio/animals/gato.mp3 | Gato! Miau! |
| assets/audio/animals/vaca.mp3 | Vaca! Muuu! |
| assets/audio/animals/cavalo.mp3 | Cavalo! Iiirrí! Pocotó, pocotó! |
| assets/audio/animals/galinha.mp3 | Galinha! Có có có! |
| assets/audio/animals/pato.mp3 | Pato! Quá quá! |
| assets/audio/animals/leao.mp3 | Leão! Roaaar! |
| assets/audio/animals/macaco.mp3 | Macaco! Uh uh ah ah! |
| assets/audio/animals/ovelha.mp3 | Ovelha! Mééé! |
| assets/audio/animals/passaro.mp3 | Pássaro! Piu piu! |

Não inclua vozes de pacientes nem informações pessoais nos arquivos. Os IDs correspondem ao catálogo em js/content/catalog.js.
