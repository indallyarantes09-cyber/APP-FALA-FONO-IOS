# Decisão técnica — Merge Cube

**Estado: provedor ainda não integrado; requer validação com o acessório físico e liberação dos direitos das imagens.**

## Candidato para esta base Electron

Avaliar um provedor local em JavaScript/WebAssembly com OpenCV: detecção das faces, estimativa de pose e filtro temporal, adaptado à interface FF.ar.registerProvider() em js/modules/ar-tracking.js. É a arquitetura que melhor encaixa no app atual sem migrar toda a experiência para Unity.

## Condições para avançar

- Obter autorização/licença para processar e distribuir as imagens oficiais das faces. A documentação pública da Merge informa que o design do Paper Cube é protegido e limita sua cópia/reprodução.
- Confirmar o uso comercial da biblioteca e os termos de qualquer pacote WASM incluído.
- Medir a calibração da câmera, oclusão, iluminação e estabilidade em Windows com o cubo físico.
- Guardar exemplos de teste sem dados de pacientes; executar tudo localmente.

## Critério de aceite

O protótipo só deve exibir conteúdo quando detectar o cubo e estimar a pose. Sem detecção, manter a cena oculta e informar que está procurando. Medir precisão/latência e confirmar cada face antes de habilitar a atividade terapêutica.

## Referências

- [Merge Help Center — Merge Cube e Paper Cube](https://support.mergeedu.com/hc/en-us/articles/360052933552-The-Real-Merge-Cube-vs-the-Paper-Cube)
- [Merge Labs — patentes do Merge Cube](https://devtest.mergeedu.com/patents)

A escolha acima é uma candidata técnica, não uma liberação de direitos nem confirmação de compatibilidade/licenciamento. Sem o cubo e autorização, não é seguro afirmar que a integração funciona ou que reconhece o acessório.
