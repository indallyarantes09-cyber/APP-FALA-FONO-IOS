# Revisão de privacidade e LGPD — Fala Fono PC

**Status: revisão técnica inicial; não é validação jurídica nem aviso de privacidade pronto para publicação.** O produto armazena dados que podem revelar saúde e pode ser usado com crianças. O controlador da clínica precisa preencher os itens marcados como pendentes antes do uso com pacientes.

## Dados e operações identificados

- Cadastro: nome, nascimento e nome do responsável.
- Registros: observações profissionais, histórico de sessão e módulos usados. O conteúdo pode incluir dados de saúde.
- Armazenamento: SQLite local no perfil do Windows. O cofre clínico segue criptografado no app com AES-GCM-256 e chave derivada do PIN; preferências e cards ficam em texto no banco local.
- Compartilhamento automático: não há serviço remoto configurado. O backup é exportado manualmente para um arquivo e pode sair do computador.
- Acesso: quem tiver acesso ao perfil do Windows pode acessar preferências, cards e arquivos de backup; o cofre clínico exige o PIN enquanto estiver bloqueado.

## Decisões pendentes do controlador

1. **Identidade e contato:** razão social/nome da clínica, contato de privacidade e encarregado, quando aplicável.
2. **Finalidades e base legal:** documentar finalidade por campo e operação; selecionar a hipótese aplicável aos dados comuns, sensíveis e de crianças/adolescentes. Não presumir que consentimento seja sempre a hipótese apropriada.
3. **Aviso ao titular/responsável:** informar finalidade, dados, base legal, retenção, compartilhamentos, direitos e canal de atendimento antes da coleta. A tela atual não fornece um aviso completo.
4. **Crianças e adolescentes:** avaliar o melhor interesse no caso concreto e definir a comunicação e o processo com o responsável.
5. **Retenção:** estabelecer prazo por categoria e rotina de descarte. O app não apaga registros automaticamente; excluir um paciente remove o registro lógico, mas cópias podem permanecer em backups manuais.
6. **Relatório de impacto:** avaliar com o responsável jurídico/privacidade se um RIPD é necessário ou recomendado para a operação concreta e mantê-lo disponível se solicitado pela ANPD.
7. **Ambiente e pessoas:** definir quem pode usar o computador, proteção da conta Windows, cópias de segurança, resposta a incidentes e procedimento para atender direitos.

## Plano técnico

- [x] Armazenar os dados clínicos como ciphertext AES-GCM no SQLite; limitar o acesso do renderer à API de armazenamento por uma ponte IPC estreita.
- [x] Manter o banco e os dados no perfil local do usuário; não adicionar telemetria nem sincronização remota.
- [x] Migrar valores legados do localStorage para SQLite na primeira leitura pelo app.
- [ ] Fazer a clínica preencher identidade, política, base legal, prazos e contatos antes de liberar o uso.
- [ ] Rever a captura e a guarda da evidência de autorização/documentação, sem apresentar uma caixa de seleção genérica como base legal suficiente.
- [ ] Definir política de exportação, retenção e descarte incluindo backups.
- [ ] Fazer revisão independente de segurança (proteção do perfil Windows, força/limite do PIN, bloqueio de tentativas, gestão de chaves e atualização de dependências).
- [ ] Validar restauração e exclusão em cópias de backup, e testar recuperação após falha do app.

## Fontes oficiais consultadas

- [Lei nº 13.709/2018 (LGPD), texto oficial](https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/l13709.htm)
- [ANPD — Enunciado CD/ANPD nº 1/2023 sobre crianças e adolescentes](https://www.gov.br/anpd/pt-br/assuntos/noticias/anpd-divulga-enunciado-sobre-o-tratamento-de-dados-pessoais-de-criancas-e-adolescentes)
- [ANPD — Perguntas frequentes sobre dados pessoais sensíveis](https://www.gov.br/anpd/pt-br/acesso-a-informacao/perguntas-frequentes)
- [ANPD — materiais educativos e publicações](https://www.gov.br/anpd/pt-br/centrais-de-conteudo/materiais-educativos-e-publicacoes)

A escolha da hipótese legal, a necessidade de RIPD e os prazos dependem do contexto da clínica e devem ser aprovados por quem responde pelo tratamento.


