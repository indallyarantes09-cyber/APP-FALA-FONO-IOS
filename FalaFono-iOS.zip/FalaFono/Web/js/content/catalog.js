/* Conteúdo educativo (dados). Adicione objetos/animais aqui; "model" referencia FF.models.
   "audio" é opcional: coloque o arquivo gravado e ele substitui a voz sintética. */
FF.catalog = {
  rooms: [
    { id: 'sala', name: 'Sala', icon: '🛋️', floor: 0xd9b38c, wall: 0xf3a35b,
      items: [
        { id: 'sofa', word: 'Sofá', art: 'o', emoji: '🛋️', model: 'sofa', pos: [-1.2, 0, -1], desc: 'No sofá a gente senta para descansar.' },
        { id: 'televisao', word: 'Televisão', art: 'a', emoji: '📺', model: 'tv', pos: [1.4, 0, -1.6], desc: 'Na televisão a gente assiste desenhos.' },
        { id: 'mesa', word: 'Mesa', art: 'a', emoji: '🪑', model: 'table', pos: [0.6, 0, 0.8], desc: 'Na mesa a gente coloca as coisas.' },
        { id: 'cadeira', word: 'Cadeira', art: 'a', emoji: '🪑', model: 'chair', pos: [-0.5, 0, 1], desc: 'Na cadeira a gente senta.' }
      ] },
    { id: 'cozinha', name: 'Cozinha', icon: '🍳', floor: 0xe8e8e8, wall: 0x9ad7d3,
      items: [
        { id: 'geladeira', word: 'Geladeira', art: 'a', emoji: '🧊', model: 'fridge', pos: [-1.5, 0, -1.4], desc: 'A geladeira deixa a comida gelada.' },
        { id: 'fogao', word: 'Fogão', art: 'o', emoji: '🔥', model: 'stove', pos: [0, 0, -1.5], desc: 'No fogão a gente cozinha.' },
        { id: 'mesa2', word: 'Mesa', art: 'a', emoji: '🍽️', model: 'table', pos: [0.9, 0, 0.7], desc: 'Na mesa a gente come.' },
        { id: 'cadeira2', word: 'Cadeira', art: 'a', emoji: '🪑', model: 'chair', pos: [-0.3, 0, 0.9], desc: 'Na cadeira a gente senta.' }
      ] },
    { id: 'quarto', name: 'Quarto', icon: '🛏️', floor: 0xc49a6c, wall: 0xb9a6f0,
      items: [
        { id: 'cama', word: 'Cama', art: 'a', emoji: '🛏️', model: 'bed', pos: [-0.6, 0, -0.6], desc: 'Na cama a gente dorme.' },
        { id: 'travesseiro', word: 'Travesseiro', art: 'o', emoji: '☁️', model: 'pillow', pos: [1.5, 0, 0.9], desc: 'O travesseiro é macio para a cabeça.' },
        { id: 'cadeira3', word: 'Cadeira', art: 'a', emoji: '🪑', model: 'chair', pos: [1.5, 0, -1.2], desc: 'Na cadeira a gente senta.' }
      ] },
    { id: 'banheiro', name: 'Banheiro', icon: '🚿', floor: 0xdfeff5, wall: 0x8fc9f0,
      items: [
        { id: 'chuveiro', word: 'Chuveiro', art: 'o', emoji: '🚿', model: 'shower', pos: [-1.3, 0, -1.3], desc: 'No chuveiro a gente toma banho.' },
        { id: 'espelho', word: 'Espelho', art: 'o', emoji: '🪞', model: 'mirror', pos: [1.1, 0, -1.7], desc: 'No espelho a gente se vê.' }
      ] }
  ],
  animals: [
    { id: 'cachorro', word: 'Cachorro', art: 'o', emoji: '🐶', model: 'dog', sound: 'Au au! Au au!', anim: 'jump' },
    { id: 'gato', word: 'Gato', art: 'o', emoji: '🐱', model: 'cat', sound: 'Miau! Miau!', anim: 'wiggle' },
    { id: 'vaca', word: 'Vaca', art: 'a', emoji: '🐮', model: 'cow', sound: 'Muuuu!', anim: 'nod' },
    { id: 'cavalo', word: 'Cavalo', art: 'o', emoji: '🐴', model: 'horse', sound: 'Iiirrí! Pocotó, pocotó!', anim: 'jump' },
    { id: 'galinha', word: 'Galinha', art: 'a', emoji: '🐔', model: 'chicken', sound: 'Có có có có!', anim: 'nod' },
    { id: 'pato', word: 'Pato', art: 'o', emoji: '🦆', model: 'duck', sound: 'Quá quá quá!', anim: 'wiggle' },
    { id: 'leao', word: 'Leão', art: 'o', emoji: '🦁', model: 'lion', sound: 'Roaaar!', anim: 'nod' },
    { id: 'macaco', word: 'Macaco', art: 'o', emoji: '🐵', model: 'monkey', sound: 'Uh uh ah ah!', anim: 'jump' },
    { id: 'ovelha', word: 'Ovelha', art: 'a', emoji: '🐑', model: 'sheep', sound: 'Méééé!', anim: 'wiggle' },
    { id: 'passaro', word: 'Pássaro', art: 'o', emoji: '🐦', model: 'bird', sound: 'Piu piu piu!', anim: 'jump' }
  ],
  /* Imagens disponíveis no editor de cards (reaproveita os módulos) */
  cardImages() {
    const s = new Map();
    this.animals.forEach(a => s.set(a.word, { emoji: a.emoji, word: a.word, sound: a.sound }));
    this.rooms.forEach(r => r.items.forEach(i => s.has(i.word) || s.set(i.word, { emoji: i.emoji, word: i.word })));
    ['⚽ Bola', '🤖 Robô', '🥁 Tambor', '🚂 Trem', '🧸 Urso', '🚀 Foguete', '👄 Boca', '👂 Orelha', '🍎 Maçã', '🚗 Carro'].forEach(x => { const [e, ...w] = x.split(' '); s.set(w.join(' '), { emoji: e, word: w.join(' ') }); });
    return [...s.values()];
  },
  audioFile(kind, id) { return `assets/audio/${kind}/${id}.mp3`; }
};
