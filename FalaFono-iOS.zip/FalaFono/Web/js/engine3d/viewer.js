/* Visualizador 3D reutilizável: câmera orbital (mouse/teclado), seleção por clique, destaque, animações. */
FF.Viewer = class {
  constructor(el, opts = {}) {
    const T = THREE, q = FF.store.settings().quality;
    this.el = el; this.opts = opts; this.items = []; this.selected = null; this.anims = [];
    try { this.renderer = new T.WebGLRenderer({ antialias: q !== 'baixa', alpha: !!opts.transparent }); }
    catch (e) { el.innerHTML = '<div class="warn">Não foi possível iniciar o 3D (WebGL indisponível). Atualize o driver de vídeo.</div>'; throw e; }
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, q === 'alta' ? 2 : q === 'media' ? 1.5 : 1));
    this.renderer.shadowMap.enabled = q !== 'baixa'; this.renderer.shadowMap.type = T.PCFSoftShadowMap;
    this.renderer.domElement.tabIndex = 0; this.renderer.domElement.setAttribute('aria-label', 'Cena 3D. Setas giram, + e - aproximam, Tab escolhe objetos.');
    el.prepend(this.renderer.domElement);
    this.scene = new T.Scene(); if (!opts.transparent) this.scene.background = new T.Color(opts.bg || 0xcfe8ff);
    this.camera = new T.PerspectiveCamera(45, 1, .1, 100);
    this.root = new T.Group(); this.scene.add(this.root);
    this.scene.add(new T.HemisphereLight(0xffffff, 0x8866aa, 1.1));
    const sun = new T.DirectionalLight(0xffffff, 1.6); sun.position.set(4, 8, 5); sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024); Object.assign(sun.shadow.camera, { left: -6, right: 6, top: 6, bottom: -6 }); this.scene.add(sun);
    this.orbit = { theta: .6, phi: 1.0, r: opts.distance || 7, target: new T.Vector3(0, .6, 0) }; this.home = { ...this.orbit, target: this.orbit.target.clone() };
    this.ray = new T.Raycaster(); this.ptr = new T.Vector2(); this.clock = new T.Clock();
    this._bind(); this._resize(); this._loop = this._loop.bind(this); this.raf = requestAnimationFrame(this._loop);
  }
  _bind() {
    const c = this.renderer.domElement; let down = null, moved = 0;
    c.addEventListener('pointerdown', e => { down = { x: e.clientX, y: e.clientY }; moved = 0; c.setPointerCapture(e.pointerId); });
    c.addEventListener('pointermove', e => { if (!down) return; const dx = e.clientX - down.x, dy = e.clientY - down.y; moved += Math.abs(dx) + Math.abs(dy); down = { x: e.clientX, y: e.clientY }; this.rotate(-dx * .008, -dy * .006); });
    c.addEventListener('pointerup', e => { if (moved < 6) this._pick(e); down = null; });
    c.addEventListener('wheel', e => { e.preventDefault(); this.zoom(e.deltaY > 0 ? 1.1 : .9); }, { passive: false });
    c.addEventListener('keydown', e => {
      const k = e.key; const map = { ArrowLeft: () => this.rotate(.12, 0), ArrowRight: () => this.rotate(-.12, 0), ArrowUp: () => this.rotate(0, .08), ArrowDown: () => this.rotate(0, -.08), '+': () => this.zoom(.9), '=': () => this.zoom(.9), '-': () => this.zoom(1.1), r: () => this.reset(), R: () => this.reset(), Enter: () => this.selected && this.opts.onSelect && this.opts.onSelect(this.selected.data, true) };
      if (map[k]) { e.preventDefault(); map[k](); }
      if (k === 'Tab' && this.items.length) { e.preventDefault(); const i = this.items.indexOf(this.selected); this.select(this.items[(i + (e.shiftKey ? -1 : 1) + this.items.length) % this.items.length].data.id, true); }
    });
    this._ro = new ResizeObserver(() => this._resize()); this._ro.observe(this.el);
  }
  rotate(dt, dp) { this.orbit.theta += dt; this.orbit.phi = Math.min(1.45, Math.max(.2, this.orbit.phi + dp)); }
  zoom(f) { this.orbit.r = Math.min(this.opts.maxDist || 14, Math.max(this.opts.minDist || 2.5, this.orbit.r * f)); }
  reset() { this.orbit = { ...this.home, target: this.home.target.clone() }; this.clearSelection(); }
  setView(v) { const p = { orbit: [.6, 1.0], frente: [0, 1.3], cima: [0, .25], lado: [1.57, 1.2] }[v]; if (p) { this.orbit.theta = p[0]; this.orbit.phi = p[1]; } }
  _resize() { const w = this.el.clientWidth || 800, h = this.el.clientHeight || 500; this.renderer.setSize(w, h, false); this.camera.aspect = w / h; this.camera.updateProjectionMatrix(); }
  add(obj, data) { obj.userData.item = data; if (data.pos) obj.position.set(...data.pos); if (data.rotY) obj.rotation.y = data.rotY; this.root.add(obj); const it = { obj, data, base: obj.position.clone(), baseRot: obj.rotation.clone() }; this.items.push(it); return it; }
  addStatic(obj) { obj.traverse(o => o.receiveShadow = true); this.root.add(obj); }
  clear() { this.items.forEach(i => this.root.remove(i.obj)); this.items = []; this.selected = null; while (this.root.children.length) this.root.remove(this.root.children[0]); }
  _pick(e) {
    const r = this.renderer.domElement.getBoundingClientRect();
    this.ptr.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
    this.ray.setFromCamera(this.ptr, this.camera);
    const hit = this.ray.intersectObjects(this.items.map(i => i.obj), true)[0];
    if (!hit) return; let o = hit.object; while (o && !o.userData.item) o = o.parent;
    if (o) this.select(o.userData.item.id, true);
  }
  select(id, notify) {
    const it = this.items.find(i => i.data.id === id); if (!it) return;
    this.clearSelection(); this.selected = it;
    it.obj.traverse(m => { if (m.isMesh) { m.userData.mat = m.material; m.material = m.material.clone(); m.material.emissive = new THREE.Color(0xffa000); m.material.emissiveIntensity = .45; } });
    const ring = new THREE.Mesh(new THREE.RingGeometry(.7, .85, 40), new THREE.MeshBasicMaterial({ color: 0xffb400, side: THREE.DoubleSide, transparent: true, opacity: .9 }));
    ring.rotation.x = -Math.PI / 2; ring.position.copy(it.base); ring.position.y = .02; this.root.add(ring); this.ring = ring;
    this.animate(id, it.data.anim || 'jump');
    if (notify && this.opts.onSelect) this.opts.onSelect(it.data);
  }
  clearSelection() {
    if (this.selected) this.selected.obj.traverse(m => { if (m.isMesh && m.userData.mat) { m.material.dispose(); m.material = m.userData.mat; } });
    if (this.ring) { this.root.remove(this.ring); this.ring = null; } this.selected = null;
  }
  animate(id, type) {
    if (FF.store.settings().reduceMotion) return;
    const it = this.items.find(i => i.data.id === id); if (it) this.anims.push({ it, type, t: 0, dur: 1.2 });
  }
  _loop() {
    this.raf = requestAnimationFrame(this._loop);
    const dt = Math.min(this.clock.getDelta(), .05), o = this.orbit, t = this.clock.elapsedTime;
    this.camera.position.set(o.target.x + o.r * Math.sin(o.phi) * Math.sin(o.theta), o.target.y + o.r * Math.cos(o.phi), o.target.z + o.r * Math.sin(o.phi) * Math.cos(o.theta));
    this.camera.lookAt(o.target);
    this.anims = this.anims.filter(a => {
      a.t += dt; const p = Math.min(a.t / a.dur, 1), s = Math.sin(p * Math.PI * 2), O = a.it.obj, B = a.it.base;
      if (a.type === 'jump') O.position.y = B.y + Math.abs(Math.sin(p * Math.PI * 2)) * .4;
      else if (a.type === 'wiggle') O.rotation.y = a.it.baseRot.y + s * .5;
      else if (a.type === 'nod') O.traverse(m => m.userData.head && (m.rotation.z = s * .4));
      if (p >= 1) { O.position.copy(B); O.rotation.copy(a.it.baseRot); O.traverse(m => m.userData.head && (m.rotation.z = 0)); }
      return p < 1;
    });
    /* animação ambiente leve (cauda, asas, água do chuveiro) */
    if (!FF.store.settings().reduceMotion) this.root.traverse(m => { if (m.userData.tail) m.rotation.x = Math.sin(t * 4) * .4; if (m.userData.wing) m.rotation.x = Math.sin(t * 6) * .15 * m.userData.wing; if (m.userData.drop) { m.position.y -= dt * 1.5; if (m.position.y < .1) m.position.y = 1.9; } });
    if (this.opts.beforeRender) this.opts.beforeRender(this);
    this.renderer.render(this.scene, this.camera);
  }
  dispose() { cancelAnimationFrame(this.raf); this._ro.disconnect(); this.renderer.dispose(); this.renderer.forceContextLoss && this.renderer.forceContextLoss(); this.renderer.domElement.remove(); }
};
/* Ambientes comuns */
FF.scenes3d = {
  room(v, room) {
    const { box } = FF.models, g = new THREE.Group();
    box(5, .1, 4.4, room.floor, 0, -.05, 0, g); box(5, 2.6, .1, room.wall, 0, 1.3, -2.2, g); box(.1, 2.6, 4.4, room.wall, -2.5, 1.3, 0, g);
    v.addStatic(g); room.items.forEach(i => v.add(FF.models.build(i.model), i));
  },
  farm(v, animals) {
    const { box, cyl, sph } = FF.models, g = new THREE.Group();
    const ground = new THREE.Mesh(new THREE.CircleGeometry(6.5, 48), FF.models.M(0x7ccf5a)); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; g.add(ground);
    [[-4.5, -3], [4.2, -3.5], [-5, 2.5], [5, 2]].forEach(([x, z]) => { cyl(.12, .15, 1, 0x7a4f2a, x, .5, z, g); sph(.7, 0x2e9e46, x, 1.5, z, g); });
    for (let i = -5; i <= 5; i += 1) box(.08, .5, .08, 0xffffff, i, .25, -4.6, g); box(10, .06, .06, 0xffffff, 0, .4, -4.6, g);
    v.addStatic(g);
    const n = animals.length; animals.forEach((a, i) => { const ang = (i / n) * Math.PI * 2, R = n > 5 ? 3.2 : 2.2; v.add(FF.models.build(a.model), Object.assign({}, a, { pos: [Math.cos(ang) * R, 0, Math.sin(ang) * R], rotY: -ang })); });
  }
};
