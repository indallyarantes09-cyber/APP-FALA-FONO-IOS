/* Modelos 3D procedurais e leves (provisórios). Para trocar por .glb, retorne o modelo carregado aqui. */
FF.models = (() => {
  const T = THREE, mats = {};
  const M = c => mats[c] || (mats[c] = new T.MeshStandardMaterial({ color: c, roughness: .7 }));
  function box(w, h, d, c, x = 0, y = 0, z = 0, g) { const m = new T.Mesh(new T.BoxGeometry(w, h, d), M(c)); m.position.set(x, y, z); m.castShadow = m.receiveShadow = true; g && g.add(m); return m; }
  function cyl(r1, r2, h, c, x = 0, y = 0, z = 0, g) { const m = new T.Mesh(new T.CylinderGeometry(r1, r2, h, 16), M(c)); m.position.set(x, y, z); m.castShadow = true; g && g.add(m); return m; }
  function sph(r, c, x = 0, y = 0, z = 0, g, sx = 1, sy = 1, sz = 1) { const m = new T.Mesh(new T.SphereGeometry(r, 20, 14), M(c)); m.position.set(x, y, z); m.scale.set(sx, sy, sz); m.castShadow = true; g && g.add(m); return m; }
  const G = () => new T.Group();
  const lib = {
    chair() { const g = G(); box(.5, .08, .5, 0xe07b39, 0, .45, 0, g); box(.5, .55, .07, 0xe07b39, 0, .75, -.22, g); [[-.2, -.2], [.2, -.2], [-.2, .2], [.2, .2]].forEach(([x, z]) => box(.06, .45, .06, 0x8a4b20, x, .22, z, g)); return g; },
    table() { const g = G(); box(1.2, .08, .8, 0xb07a4a, 0, .72, 0, g); [[-.5, -.32], [.5, -.32], [-.5, .32], [.5, .32]].forEach(([x, z]) => box(.08, .7, .08, 0x7a4f2a, x, .35, z, g)); sph(.1, 0xff4d4d, .2, .85, 0, g); return g; },
    sofa() { const g = G(); box(1.6, .4, .8, 0x3f7fd9, 0, .3, 0, g); box(1.6, .5, .2, 0x2f6ac0, 0, .7, -.3, g); box(.2, .35, .8, 0x2f6ac0, -.8, .55, 0, g); box(.2, .35, .8, 0x2f6ac0, .8, .55, 0, g); return g; },
    tv() { const g = G(); box(1.4, .45, .45, 0xffffff, 0, .22, 0, g); box(1.2, .7, .06, 0x111111, 0, .95, 0, g); const s = box(1.1, .6, .01, 0x2a6cff, 0, .95, .035, g); s.material = new T.MeshStandardMaterial({ color: 0x2a6cff, emissive: 0x1a3fa0 }); return g; },
    fridge() { const g = G(); box(.7, 1.7, .65, 0xf2f6fa, 0, .85, 0, g); box(.04, .3, .04, 0x999999, .28, 1.2, .34, g); box(.04, .3, .04, 0x999999, .28, .5, .34, g); box(.7, .02, .66, 0xcccccc, 0, 1.05, 0, g); return g; },
    stove() { const g = G(); box(.8, .85, .65, 0xdddddd, 0, .42, 0, g); box(.6, .35, .02, 0x333333, 0, .4, .33, g); [[-.2, -.15], [.2, -.15], [-.2, .15], [.2, .15]].forEach(([x, z]) => cyl(.1, .1, .03, 0x222222, x, .87, z, g)); cyl(.2, .18, .2, 0xd94040, -.2, .98, .15, g); return g; },
    bed() { const g = G(); box(1.2, .35, 2, 0x8a5a3a, 0, .2, 0, g); box(1.15, .2, 1.9, 0xffffff, 0, .47, 0, g); box(1.17, .1, 1.3, 0xf26f21, 0, .6, .3, g); box(1.2, .8, .1, 0x8a5a3a, 0, .5, -1, g); box(.7, .14, .35, 0xfff6d6, 0, .64, -.7, g); return g; },
    pillow() { const g = G(); sph(.4, 0xfff6d6, 0, .2, 0, g, 1.3, .45, .9); return g; },
    mirror() { const g = G(); cyl(.5, .5, .06, 0xf5b921, 0, 1.3, 0, g).rotation.x = Math.PI / 2; const m = cyl(.43, .43, .07, 0xbfe6ff, 0, 1.3, .01, g); m.rotation.x = Math.PI / 2; m.material = new T.MeshStandardMaterial({ color: 0xcfeeff, metalness: .9, roughness: .05 }); box(.9, .5, .45, 0xffffff, 0, .25, .1, g); return g; },
    shower() { const g = G(); cyl(.03, .03, 2, 0xaaaaaa, 0, 1, 0, g); box(.4, .03, .03, 0xaaaaaa, .2, 2, 0, g); cyl(.15, .08, .08, 0xcccccc, .4, 1.95, 0, g); box(1, .05, 1, 0xbfe6ff, .3, .03, .2, g); for (let i = 0; i < 12; i++) { const d = sph(.025, 0x6ec6ff, .3 + (Math.random() - .5) * .2, .3 + Math.random() * 1.5, (Math.random() - .5) * .2, g); d.userData.drop = true; } return g; },
    /* animais */
    quad(o) {
      const g = G(), c = o.color;
      sph(.45, c, 0, .7, 0, g, 1.4 * (o.bodyL || 1), .9, .9);
      const head = G(); head.position.set(.65 * (o.bodyL || 1), 1.05 + (o.neck || 0), 0); g.add(head); head.userData.head = true;
      sph(.3, o.headColor || c, 0, 0, 0, head);
      sph(.14, o.snout || 0xf5d5b5, .25, -.07, 0, head, 1.2, .8, 1);
      sph(.05, 0x111111, .2, .1, .13, head); sph(.05, 0x111111, .2, .1, -.13, head);
      sph(.04, 0x222222, .4, -.03, 0, head);
      (o.ears || 'up') === 'up' ? [.15, -.15].forEach(z => sph(.09, o.earColor || c, -.05, .28, z, head, .6, 1.4, .8)) : [.27, -.27].forEach(z => sph(.1, o.earColor || c, -.03, .05, z, head, .6, 1.2, .5));
      [[.4, .22], [.4, -.22], [-.4, .22], [-.4, -.22]].forEach(([x, z]) => cyl(.08, .07, .5 * (o.legL || 1), o.legColor || c, x * (o.bodyL || 1), .5 - .25 * (o.legL || 1) + .02, z, g));
      const tail = cyl(.04, .03, .5, o.tailColor || c, -.75 * (o.bodyL || 1), .85, 0, g); tail.rotation.z = .9; tail.userData.tail = true;
      if (o.mane) sph(.42, o.mane, .55, 1.05, 0, g, .8, 1, 1.05);
      if (o.spots) [[.1, .9, .3], [-.3, .7, -.35], [.3, .6, .34]].forEach(p => sph(.15, o.spots, ...p, g, 1, 1, .4));
      if (o.horns) [.12, -.12].forEach(z => cyl(.03, .01, .15, 0xfff3c4, .6 * (o.bodyL || 1), 1.42, z, g));
      if (o.wool) for (let i = 0; i < 9; i++) sph(.22, 0xffffff, -.4 + (i % 3) * .4, .8 + Math.floor(i / 3) * .1, -.25 + (Math.floor(i / 3)) * .25, g);
      return g;
    },
    birdish(o) {
      const g = G();
      sph(.4, o.color, 0, .55, 0, g, 1.1, 1, .9);
      const head = G(); head.position.set(.3, 1, 0); g.add(head); head.userData.head = true;
      sph(.25, o.color, 0, 0, 0, head);
      const beak = new THREE.Mesh(new THREE.ConeGeometry(.08, .25, 12), M(o.beak || 0xf5a623)); beak.rotation.z = -Math.PI / 2; beak.position.set(.3, -.03, 0); if (o.flat) beak.scale.set(1.4, 1, 1.8); head.add(beak);
      sph(.04, 0x111111, .15, .08, .14, head); sph(.04, 0x111111, .15, .08, -.14, head);
      if (o.comb) sph(.08, 0xe02020, 0, .26, 0, head, 1.5, 1, .5);
      [.38, -.38].forEach(z => { const w = sph(.25, o.wing || o.color, -.05, .6, z, g, 1.2, .7, .3); w.userData.wing = z > 0 ? 1 : -1; });
      [.12, -.12].forEach(z => cyl(.025, .025, .35, 0xf5a623, 0, .15, z, g));
      return g;
    },
    dog() { return lib.quad({ color: 0xc8874a, ears: 'down', earColor: 0x7a4a20, snout: 0xe8c39a }); },
    cat() { return lib.quad({ color: 0x9a9a9a, ears: 'up', snout: 0xffffff, bodyL: .9, legL: .9 }); },
    cow() { return lib.quad({ color: 0xffffff, spots: 0x222222, horns: true, snout: 0xf7b7c8, ears: 'down' }); },
    horse() { return lib.quad({ color: 0x8b5a2b, neck: .3, legL: 1.5, bodyL: 1.1, mane: null, tailColor: 0x3b2410, snout: 0x6b4423 }); },
    lion() { return lib.quad({ color: 0xe8b04a, mane: 0xa0561c, snout: 0xf5dfb0, ears: 'up', tailColor: 0xa0561c }); },
    sheep() { return lib.quad({ color: 0xf2f2f2, wool: true, headColor: 0x333333, snout: 0x444444, legColor: 0x333333, ears: 'down', earColor: 0x333333 }); },
    monkey() { const g = lib.quad({ color: 0x7a4a2a, snout: 0xf1c79b, ears: 'down', earColor: 0xf1c79b, bodyL: .8, legL: 1.2 }); g.rotation.z = .5; g.position.y = .2; const w = G(); w.add(g); return w; },
    chicken() { return lib.birdish({ color: 0xffffff, comb: true, wing: 0xf3f3f3 }); },
    duck() { return lib.birdish({ color: 0xf8d830, beak: 0xff8c1a, flat: true }); },
    bird() { const g = lib.birdish({ color: 0x3fa9f5, wing: 0x1f6fc0 }); g.scale.setScalar(.7); const w = G(); w.add(g); return w; }
  };
  function build(name) {
    try { if (!lib[name]) throw new Error('Modelo inexistente: ' + name); return lib[name](); }
    catch (e) { console.warn(e); const g = G(); box(.5, .5, .5, 0xff00ff, 0, .25, 0, g); return g; /* placeholder visível */ }
  }
  return { build, box, cyl, sph, M };
})();
