FF.applySettings = () => {
  const s = FF.store.settings();
  document.documentElement.style.setProperty('--fs', s.fontScale);
  document.body.classList.toggle('reduce-motion', s.reduceMotion);
  document.getElementById('guide').classList.toggle('hidden', !s.guide);
};
document.getElementById('btn-fullscreen').onclick = () => document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen().catch(() => FF.ui.toast('Tela cheia indisponível.'));
document.getElementById('btn-stop-audio').onclick = () => FF.audio.stop();
addEventListener('keydown', e => { if (e.key === 'Escape') FF.audio.stop(); if (e.key === 'F11' && !window.falafonoNative) { e.preventDefault(); document.getElementById('btn-fullscreen').click(); } });
addEventListener('error', e => console.error('Erro capturado:', e.message));
addEventListener('unhandledrejection', e => { console.error(e.reason); FF.ui.toast('Ocorreu um erro, mas o app continua funcionando.'); });
['pointerdown', 'keydown'].forEach(t => addEventListener(t, () => FF.vault.key && FF.vault.touch()));
FF.applySettings();
FF.router.go('welcome');
