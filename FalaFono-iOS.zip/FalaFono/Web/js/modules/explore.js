/* "Explorar em 3D": módulo genérico usado por Minha Casa e Animais e seus Sons. */
FF.explore = function (kind) {
  let v = null, quiz = null;
  const C = FF.catalog, isAnimals = kind === 'animals';
  const phrase = d => (d.art === 'a' ? 'Esta é uma ' : 'Este é um ') + d.word.toLowerCase() + '.';
  function speakItem(d, soundOnly) {
    if (isAnimals) {
      FF.audio.say(soundOnly ? { text: d.sound, file: C.audioFile('animals', d.id) } : { text: d.word + '! ' + d.sound, file: C.audioFile('animals', d.id) }, { force: true });
    } else FF.audio.say({ text: d.word + '. ' + phrase(d), file: C.audioFile('words', d.id) }, { force: true });
  }
  return {
    title: isAnimals ? 'Animais e seus Sons' : 'Minha Casa',
    mount(el, params) {
      const room = C.rooms.find(r => r.id === params.room) || C.rooms[0];
      const acts = (FF.session && FF.session.activities) || { quiz: true };
      el.innerHTML = `
      <div class="topbar"><button class="btn ghost" id="back">⬅ Voltar</button><span class="pill">CUBO 3D</span><h1 style="margin:0">${this.title}</h1></div>
      <div class="stage">
        <div class="viewport" id="vp"><div class="vp-hint">🖱️ Arraste para girar · roda = zoom · clique no objeto · Tab/Enter no teclado</div><div class="vp-label" id="label" style="opacity:0"></div></div>
        <div class="panel">
          ${isAnimals ? '' : `<h3>Cômodos</h3><div class="chips" id="rooms">${C.rooms.map(r => `<button data-room="${r.id}" class="${r.id === room.id ? 'sel' : ''}">${r.icon} ${r.name}</button>`).join('')}</div>`}
          <h3>${isAnimals ? 'Animais' : 'Objetos'}</h3>
          <div class="chips" id="items"></div>
          <div class="info" id="info">${isAnimals ? 'Clique em um animal para ouvir seu som!' : 'Toque nos objetos e aprenda seu nome.'}</div>
          <div class="row"><button class="btn" id="repeat">🔁 Repetir</button><button class="btn ghost" id="stop">⏹ Parar</button></div>
          <div class="row"><button class="btn ghost" id="reset">↺ Reiniciar cena</button>
            <select id="viewmode" aria-label="Modo de visualização"><option value="orbit">Vista livre</option><option value="frente">Frente</option><option value="cima">De cima</option><option value="lado">Lateral</option></select></div>
          ${acts.quiz !== false ? `<button class="btn yel" id="quizbtn">🎯 ${isAnimals ? 'Adivinhe pelo som' : 'Encontre o objeto'}</button><div id="quiz"></div>` : ''}
          <button class="btn alt" data-go="ar" data-params='${JSON.stringify({ content: kind, room: room.id })}'>🧊 Usar Merge Cube <span class="badge">${FF.ar.statusLabel()}</span></button>
        </div>
      </div>`;
      const items = isAnimals ? C.animals : room.items;
      el.querySelector('#items').innerHTML = items.map(i => `<button data-id="${i.id}">${i.emoji} ${i.word}</button>`).join('');
      const label = el.querySelector('#label'), info = el.querySelector('#info');
      const onSelect = d => {
        el.querySelectorAll('#items button').forEach(b => b.classList.toggle('sel', b.dataset.id === d.id));
        label.textContent = d.emoji + ' ' + d.word; label.style.opacity = 1;
        info.innerHTML = `<b style="font-size:1.4rem">${d.word}</b><br>${isAnimals ? `${d.art === 'a' ? 'A' : 'O'} ${d.word.toLowerCase()} faz: <b>${d.sound}</b>` : phrase(d) + '<br><small>' + (d.desc || '') + '</small>'}`;
        if (quiz) return checkQuiz(d);
        speakItem(d);
      };
      v = new FF.Viewer(el.querySelector('#vp'), { onSelect, distance: isAnimals ? 10 : 7.5, bg: isAnimals ? 0xbfe6ff : 0xe9e1ff });
      isAnimals ? FF.scenes3d.farm(v, C.animals) : FF.scenes3d.room(v, room);
      el.querySelector('#items').onclick = e => { const b = e.target.closest('button'); if (b) v.select(b.dataset.id, true); };
      const rooms = el.querySelector('#rooms'); if (rooms) rooms.onclick = e => { const b = e.target.closest('button'); if (b) FF.router.go('house', { room: b.dataset.room }, false); };
      el.querySelector('#back').onclick = () => FF.router.back();
      el.querySelector('#repeat').onclick = () => v.selected ? speakItem(v.selected.data) : FF.audio.repeat();
      el.querySelector('#stop').onclick = () => FF.audio.stop();
      el.querySelector('#reset').onclick = () => { v.reset(); label.style.opacity = 0; quiz = null; const q = el.querySelector('#quiz'); if (q) q.innerHTML = ''; };
      el.querySelector('#viewmode').onchange = e => v.setView(e.target.value);
      const qb = el.querySelector('#quizbtn');
      if (qb) qb.onclick = () => {
        const target = items[Math.floor(Math.random() * items.length)];
        const opts = [target, ...items.filter(i => i.id !== target.id).sort(() => Math.random() - .5).slice(0, 2)].sort(() => Math.random() - .5);
        quiz = target;
        el.querySelector('#quiz').innerHTML = `<div class="quiz"><b>${isAnimals ? 'Qual animal faz este som?' : `Onde está ${target.art} ${target.word.toLowerCase()}?`}</b><br>
          <button data-a="${target.id}" id="qplay">🔊 Ouvir</button>${opts.map(o => `<button data-pick="${o.id}">${o.emoji} ${isAnimals ? o.word : o.word}</button>`).join('')}<div id="qres"></div><small>Você também pode clicar no 3D.</small></div>`;
        const play = () => isAnimals ? speakItem(target, true) : FF.audio.say(`Onde está ${target.art} ${target.word.toLowerCase()}?`, { force: true });
        el.querySelector('#qplay').onclick = play; play();
        el.querySelectorAll('[data-pick]').forEach(b => b.onclick = () => v.select(b.dataset.pick, true));
      };
      function checkQuiz(d) {
        const r = el.querySelector('#qres'); if (!r) return;
        if (d.id === quiz.id) { r.innerHTML = '🎉 <b>Muito bem!</b>'; FF.audio.sfx('ok'); speakItem(d); FF.ui.guide('Muito bem! 🎉'); quiz = null; FF.clinicalLog && FF.clinicalLog(kind, 'Atividade de associação concluída: ' + d.word); }
        else { r.innerHTML = '🤔 Tente de novo!'; FF.audio.sfx('err'); }
      }
      FF.clinicalLog && FF.clinicalLog(kind, 'Módulo aberto' + (isAnimals ? '' : ': ' + room.name));
      FF.ui.guide(isAnimals ? 'Clique em um animal para ouvir seu som!' : 'Vamos conhecer os objetos da casa?');
      v.renderer.domElement.focus();
    },
    unmount() { v && v.dispose(); v = null; quiz = null; }
  };
};
FF.modules.house = FF.explore('house');
FF.modules.animals = FF.explore('animals');
