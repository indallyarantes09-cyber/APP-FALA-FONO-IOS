/* Editor e biblioteca de cards educativos */
FF.modules.cards = (() => {
  const load = () => { const c = FF.store.get('cards', null); return Array.isArray(c) ? c : seed(); };
  const seed = () => [['⚽', 'Bola'], ['🤖', 'Robô'], ['🥁', 'Tambor'], ['🚂', 'Trem'], ['🧸', 'Urso'], ['🚀', 'Foguete'], ['👄', 'Boca']].map(([e, w], i) => ({ id: 'seed' + i, emoji: e, word: w, phrase: '', template: 'classico', color: '#f8d55a', textColor: '#3b2a00', size: 26 }));
  const esc = FF.ui.esc;
  function render(c, acts) {
    const st = c.template === 'solido' ? `background:${c.color};border-color:${c.color};color:${c.textColor}` : c.template === 'moldura' ? `border-color:${c.color};color:${c.textColor}` : `color:${c.textColor}`;
    return `<div class="ecard t-${c.template}" style="${st}" data-id="${c.id}"><div class="img">${c.image ? `<img src="${c.image}" alt="">` : esc(c.emoji || '❓')}</div><div class="w" style="font-size:${c.size}px">${esc(c.word)}</div><div class="ph">${esc(c.phrase)}</div>
      ${acts ? `<div class="acts no-print"><button data-a="play" title="Ouvir">🔊</button><button data-a="edit">✏️</button><button data-a="del">🗑️</button></div>` : ''}</div>`;
  }
  return {
    title: 'Criar Cards',
    mount(el) {
      let cards = load(), edit = null;
      const blank = () => ({ id: 'c' + Date.now(), emoji: '🐶', word: '', phrase: '', template: 'classico', color: '#f8d55a', textColor: '#3b2a00', size: 26, sound: '' });
      let cur = blank();
      el.innerHTML = `<div class="topbar no-print"><button class="btn ghost" id="back">⬅ Voltar</button><span class="pill">Card's</span></div>
      <div class="cards-layout"><div class="form no-print">
        <h2 id="ftitle">Crie seu Card</h2>
        <label>Imagem (dos módulos)<div class="picker" id="pick">${FF.catalog.cardImages().map(i => `<button data-e="${i.emoji}" data-w="${esc(i.word)}" data-s="${esc(i.sound || '')}" title="${esc(i.word)}">${i.emoji}</button>`).join('')}</div></label>
        <label>Ou envie uma imagem<input type="file" id="file" accept="image/*"></label>
        <label>Palavra<input id="word" maxlength="30"></label>
        <label>Frase curta<input id="phrase" maxlength="60"></label>
        <label>Modelo<select id="template"><option value="classico">Clássico (amarelo)</option><option value="moldura">Moldura</option><option value="solido">Cor sólida</option></select></label>
        <div class="row"><label>Cor<input type="color" id="color"></label><label>Texto<input type="color" id="textColor"></label></div>
        <label>Tamanho do texto: <span id="sv"></span><input type="range" id="size" min="16" max="48"></label>
        <h3>Prévia</h3><div id="preview" style="max-width:200px"></div>
        <div class="row"><button class="btn" id="save">💾 Salvar</button><button class="btn ghost" id="new">Novo</button></div>
      </div>
      <div><div class="row no-print" style="margin-bottom:12px;flex:0"><button class="btn yel" id="print">🖨️ Imprimir / PDF</button><button class="btn ghost" id="export">⬇ Exportar</button><label class="btn ghost" style="flex-direction:row;align-items:center">⬆ Importar<input type="file" id="import" accept=".json" hidden></label></div>
        <div class="lib" id="lib"></div></div></div>`;
      const $ = s => el.querySelector(s), fields = ['word', 'phrase', 'template', 'color', 'textColor', 'size'];
      const fill = () => { fields.forEach(f => $('#' + f).value = cur[f]); $('#sv').textContent = cur.size + 'px'; preview(); };
      const preview = () => $('#preview').innerHTML = render(cur);
      const lib = () => $('#lib').innerHTML = cards.map(c => render(c, true)).join('') || '<p>Nenhum card ainda.</p>';
      fields.forEach(f => $('#' + f).oninput = e => { cur[f] = f === 'size' ? +e.target.value : e.target.value; $('#sv').textContent = cur.size + 'px'; preview(); });
      $('#pick').onclick = e => { const b = e.target.closest('button'); if (!b) return; cur.emoji = b.dataset.e; cur.image = null; cur.sound = b.dataset.s; if (!cur.word) cur.word = b.dataset.w; fill(); };
      $('#file').onchange = e => { const f = e.target.files[0]; if (!f) return; if (f.size > 1.5e6) return FF.ui.toast('Imagem muito grande (máx. 1,5 MB).'); const r = new FileReader(); r.onload = () => { cur.image = r.result; preview(); }; r.onerror = () => FF.ui.toast('Não foi possível ler a imagem.'); r.readAsDataURL(f); };
      $('#save').onclick = () => {
        if (!cur.word.trim()) return FF.ui.toast('Digite uma palavra para o card.');
        const i = cards.findIndex(c => c.id === cur.id); i >= 0 ? cards[i] = { ...cur } : cards.push({ ...cur });
        if (FF.store.set('cards', cards)) { FF.ui.toast('Card salvo!'); FF.audio.sfx('ok'); cur = blank(); $('#ftitle').textContent = 'Crie seu Card'; fill(); lib(); }
      };
      $('#new').onclick = () => { cur = blank(); $('#ftitle').textContent = 'Crie seu Card'; fill(); };
      $('#lib').onclick = e => {
        const b = e.target.closest('button'), card = e.target.closest('.ecard'); if (!card) return;
        const c = cards.find(x => x.id === card.dataset.id); const a = b ? b.dataset.a : 'play';
        if (a === 'play') FF.audio.say(c.word + '. ' + (c.sound || c.phrase || ''), { force: true });
        if (a === 'edit') { cur = { ...c }; $('#ftitle').textContent = 'Editar card'; fill(); }
        if (a === 'del' && confirm(`Excluir o card "${c.word}"?`)) { cards = cards.filter(x => x.id !== c.id); FF.store.set('cards', cards); lib(); }
      };
      $('#print').onclick = () => {
        if (window.falafonoNative && window.webkit?.messageHandlers?.falaFonoPrint) {
          window.webkit.messageHandlers.falaFonoPrint.postMessage({ cards });
        } else print();
      };
      $('#export').onclick = () => {
        const content = JSON.stringify(cards, null, 1);
        if (window.falafonoNative && window.webkit?.messageHandlers?.falaFonoExport) {
          window.webkit.messageHandlers.falaFonoExport.postMessage({ filename: 'falafono-cards.json', mimeType: 'application/json', content });
          return;
        }
        const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([content], { type: 'application/json' })); a.download = 'falafono-cards.json'; a.click();
      };
      $('#import').onchange = e => { const f = e.target.files[0]; if (!f) return; f.text().then(t => { const d = JSON.parse(t); if (!Array.isArray(d) || d.some(c => typeof c.word !== 'string')) throw new Error(); cards = cards.concat(d.map(c => ({ ...blank(), ...c, id: 'c' + Math.random().toString(36).slice(2) }))); FF.store.set('cards', cards); lib(); FF.ui.toast(d.length + ' cards importados.'); }).catch(() => FF.ui.toast('Arquivo de cards inválido.')); };
      $('#back').onclick = () => FF.router.back();
      fill(); lib(); FF.ui.guide('Escolha uma imagem, escreva a palavra e salve!');
    }
  };
})();
