/* Área clínica: dados criptografados localmente (AES-GCM, chave derivada do PIN, nunca enviada à rede). */
FF.vault = { key: null, data: null, timer: null,
  async save() { if (!this.key) return false; const box = await FF.store.crypto.encrypt(this.key, this.data); return FF.store.set('clinical.box', box); },
  lock() { this.key = null; this.data = null; FF.session = null; FF.renderSessionBar(); },
  touch() { clearTimeout(this.timer); this.timer = setTimeout(() => { this.lock(); FF.ui.toast('Área clínica bloqueada por inatividade.'); if (FF.router.current && FF.router.current.name === 'clinical') FF.router.go('clinical', {}, false); }, 15 * 60 * 1000); }
};
/* Registro factual de atividades da sessão ativa (sem pontuações ou interpretações clínicas) */
FF.clinicalLog = (module, text) => {
  const s = FF.session, V = FF.vault; if (!s || !V.data) return;
  const p = V.data.patients.find(p => p.id === s.patientId); if (!p) return;
  p.history.push({ at: new Date().toISOString(), type: 'atividade', module, text }); V.save();
};
FF.renderSessionBar = () => {
  const b = document.getElementById('session-bar'), s = FF.session;
  if (!s || !FF.vault.data) { b.hidden = true; return; }
  const p = FF.vault.data.patients.find(p => p.id === s.patientId);
  const names = { house: '🏠 Minha Casa', animals: '🐶 Animais', cards: '🃏 Cards', ar: '🧊 Merge Cube' };
  b.hidden = false; b.innerHTML = `<b>Sessão:</b> ${FF.ui.esc(p ? p.name : '')}${s.modules.map(m => `<button data-go="${m}">${names[m]}</button>`).join('')}<button data-go="clinical" style="background:#d9354a">Encerrar/registrar</button>`;
};
FF.modules.clinical = (() => {
  const esc = FF.ui.esc, C = FF.store.crypto;
  let sel = null;
  return {
    title: 'Área Clínica',
    mount(el) {
      const V = FF.vault;
      el.innerHTML = `<div class="topbar"><button class="btn ghost" id="back">⬅ Voltar</button><h1 style="margin:0">Área Clínica</h1>${V.key ? '<button class="btn ghost" id="lock">🔒 Bloquear</button>' : ''}</div><div id="body"></div>`;
      el.querySelector('#back').onclick = () => FF.router.back();
      const lk = el.querySelector('#lock'); if (lk) lk.onclick = () => { V.lock(); FF.router.go('clinical', {}, false); };
      const body = el.querySelector('#body');
      if (!crypto.subtle) { body.innerHTML = '<div class="warn">Criptografia indisponível neste ambiente. Execute pelo aplicativo (Electron) ou por http://localhost.</div>'; return; }
      V.key ? this.main(body) : this.unlock(body);
    },
    unlock(body) {
      const box = FF.store.get('clinical.box', null), first = !box;
      body.innerHTML = `<div class="card-box" style="max-width:460px"><h2>${first ? 'Criar PIN de acesso' : 'Acesso do profissional'}</h2>
        <p class="sub">${first ? 'Crie um PIN (mín. 6 dígitos). Ele protege e criptografa os dados dos pacientes neste computador. Sem o PIN os dados não podem ser recuperados.' : 'Digite seu PIN.'}</p>
        <form id="f"><label>PIN<input type="password" id="pin" inputmode="numeric" autocomplete="current-password" required minlength="6"></label>${first ? '<label>Confirmar PIN<input type="password" id="pin2" required minlength="6"></label>' : ''}<br><button class="btn">Entrar</button></form></div>`;
      body.querySelector('#f').onsubmit = async e => {
        e.preventDefault(); const pin = body.querySelector('#pin').value;
        try {
          if (first) {
            if (pin !== body.querySelector('#pin2').value) return FF.ui.toast('Os PINs não conferem.');
            const salt = crypto.getRandomValues(new Uint8Array(16)); FF.store.set('clinical.salt', C.b64(salt));
            FF.vault.key = await C.key(pin, salt); FF.vault.data = { patients: [] }; await FF.vault.save();
          } else {
            const k = await C.key(pin, C.unb64(FF.store.get('clinical.salt'))); FF.vault.data = await C.decrypt(k, box); FF.vault.key = k;
          }
          FF.vault.touch(); FF.router.go('clinical', {}, false);
        } catch (err) { FF.audio.sfx('err'); FF.ui.toast(first ? 'Erro ao criar o cofre.' : 'PIN incorreto ou dados corrompidos.'); }
      };
    },
    main(body) {
      const V = FF.vault, D = V.data; V.touch();
      const save = async () => { if (!(await V.save())) FF.ui.toast('Falha ao salvar registro.'); };
      const draw = () => {
        const q = (body.querySelector('#q') || {}).value || '';
        const p = D.patients.find(x => x.id === sel);
        body.innerHTML = `<div class="clin"><div class="card-box"><input id="q" placeholder="🔎 Buscar paciente" value="${esc(q)}" style="width:100%;margin-bottom:10px">
          <div class="plist">${D.patients.filter(x => x.name.toLowerCase().includes(q.toLowerCase())).sort((a, b) => a.name.localeCompare(b.name)).map(x => `<button data-p="${x.id}" class="${x.id === sel ? 'sel' : ''}">${esc(x.name)}</button>`).join('') || '<p>Nenhum paciente.</p>'}</div>
          <button class="btn alt" id="add" style="width:100%">＋ Cadastrar paciente</button>
          <div class="row" style="margin-top:10px"><button class="btn ghost" id="bk">⬇ Backup</button><label class="btn ghost" style="flex-direction:row;justify-content:center">⬆ Restaurar<input type="file" id="rs" hidden accept=".json"></label></div>
          <p class="sub" style="font-size:.8rem;margin-top:10px">Dados armazenados apenas neste computador, criptografados. O backup também é criptografado (requer o mesmo PIN).</p></div>
        <div>${p ? patient(p) : '<div class="card-box"><h2>Selecione ou cadastre um paciente</h2><p class="sub">Armazene apenas o necessário (minimização de dados — LGPD).</p></div>'}</div></div>`;
        body.querySelector('#q').oninput = () => { const pos = body.querySelector('#q').selectionStart; draw(); const i = body.querySelector('#q'); i.focus(); i.setSelectionRange(pos, pos); };
        body.querySelector('.plist').onclick = e => { const b = e.target.closest('[data-p]'); if (b) { sel = b.dataset.p; draw(); } };
        body.querySelector('#add').onclick = () => { sel = null; form(); };
        body.querySelector('#bk').onclick = () => {
          const content = JSON.stringify({ app: 'falafono', v: 1, salt: FF.store.get('clinical.salt'), box: FF.store.get('clinical.box') }, null, 2);
          const filename = 'falafono-backup-' + new Date().toISOString().slice(0, 10) + '.json';
          if (window.falafonoNative && window.webkit?.messageHandlers?.falaFonoExport) {
            window.webkit.messageHandlers.falaFonoExport.postMessage({ filename, mimeType: 'application/json', content });
            return;
          }
          const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([content], { type: 'application/json' })); a.download = filename; a.click();
        };
        body.querySelector('#rs').onchange = async e => {
          try { const b = JSON.parse(await e.target.files[0].text()); if (b.app !== 'falafono') throw 0; const pin = prompt('PIN do backup:'); const k = await C.key(pin, C.unb64(b.salt)); const d = await C.decrypt(k, b.box);
            if (!confirm('Substituir os dados atuais pelos do backup?')) return; FF.store.set('clinical.salt', b.salt); V.key = k; V.data = d; await save(); FF.router.go('clinical', {}, false); }
          catch (err) { FF.ui.toast('Backup inválido ou PIN incorreto.'); }
        };
        if (p) bindPatient(p);
      };
      const patient = p => `<div class="card-box"><div class="topbar" style="margin:0"><div style="width:64px;height:64px;border-radius:50%;background:var(--laranja);display:grid;place-items:center;font-size:2rem">👤</div><div><h2 style="margin:0">${esc(p.name)}</h2><small>${p.birth ? 'Nasc.: ' + esc(p.birth) : ''} ${p.guardian ? '· Resp.: ' + esc(p.guardian) : ''}</small></div><button class="btn ghost" id="ed">✏️ Editar</button><button class="btn danger" id="del">🗑️ Excluir</button></div></div>
        <div class="card-box"><h2>📅 Agenda e sessões — preparar sessão</h2><div class="chips" id="mods">${[['house', '🏠 Minha Casa'], ['animals', '🐶 Animais e seus Sons'], ['cards', '🃏 Cards personalizados'], ['ar', '🧊 Merge Cube']].map(([m, n]) => `<label style="flex-direction:row;background:#ffffff1f;padding:8px 12px;border-radius:12px"><input type="checkbox" value="${m}" ${m !== 'ar' ? 'checked' : ''}> ${n}</label>`).join('')}</div>
          <label style="flex-direction:row;margin-top:8px"><input type="checkbox" id="quiz" checked> Ativar atividades de associação (quiz)</label>
          <div class="row" style="margin-top:8px">${FF.session && FF.session.patientId === p.id ? '<button class="btn danger" id="end">⏹ Encerrar sessão</button>' : '<button class="btn" id="startS">▶ Iniciar sessão</button>'}</div></div>
        <div class="card-box"><h2>📝 Registrar observação</h2><textarea id="obs" rows="3" style="width:100%" placeholder="Observações do profissional"></textarea><button class="btn alt" id="addObs">Salvar observação</button></div>
        <div class="card-box"><h2>📋 Histórico clínico</h2><p class="sub" style="font-size:.85rem">Registro factual de atividades e observações. Não há pontuações nem diagnósticos automáticos.</p>
        <table><tr><th>Data</th><th>Tipo</th><th>Registro</th></tr>${p.history.slice().reverse().map(h => `<tr><td>${new Date(h.at).toLocaleString('pt-BR')}</td><td>${esc(h.type)}${h.module ? ' · ' + esc(h.module) : ''}</td><td>${esc(h.text)}</td></tr>`).join('') || '<tr><td colspan=3>Sem registros.</td></tr>'}</table></div>`;
      const bindPatient = p => {
        const $ = s => body.querySelector(s);
        $('#ed').onclick = () => form(p);
        $('#del').onclick = async () => { if (prompt(`Para excluir definitivamente, digite o nome: ${p.name}`) !== p.name) return FF.ui.toast('Exclusão cancelada.'); D.patients = D.patients.filter(x => x.id !== p.id); if (FF.session && FF.session.patientId === p.id) FF.session = null; sel = null; await save(); FF.renderSessionBar(); draw(); };
        $('#addObs').onclick = async () => { const t = $('#obs').value.trim(); if (!t) return; p.history.push({ at: new Date().toISOString(), type: 'observação', text: t }); await save(); draw(); };
        const st = $('#startS'); if (st) st.onclick = async () => {
          const modules = [...body.querySelectorAll('#mods input:checked')].map(i => i.value); if (!modules.length) return FF.ui.toast('Selecione ao menos um módulo.');
          FF.session = { patientId: p.id, modules, activities: { quiz: $('#quiz').checked }, startedAt: Date.now() };
          p.history.push({ at: new Date().toISOString(), type: 'sessão', text: 'Sessão iniciada: ' + modules.join(', ') }); await save(); FF.renderSessionBar(); FF.router.go(modules[0]);
        };
        const en = $('#end'); if (en) en.onclick = async () => { p.history.push({ at: new Date().toISOString(), type: 'sessão', text: 'Sessão encerrada (' + Math.round((Date.now() - FF.session.startedAt) / 60000) + ' min)' }); FF.session = null; await save(); FF.renderSessionBar(); draw(); };
      };
      const form = p => {
        const x = p || { name: '', birth: '', guardian: '' };
        body.innerHTML = `<div class="card-box" style="max-width:520px"><h2>${p ? 'Editar' : 'Cadastrar'} paciente</h2><form id="pf">
          <label>Nome*<input id="name" required maxlength="80" value="${esc(x.name)}"></label><label>Data de nascimento<input type="date" id="birth" value="${esc(x.birth)}"></label><label>Responsável<input id="guardian" maxlength="80" value="${esc(x.guardian)}"></label>
          <label style="flex-direction:row"><input type="checkbox" required ${p ? 'checked' : ''}> Consentimento do titular/responsável para o tratamento dos dados obtido</label>
          <div class="row"><button class="btn">Salvar</button><button type="button" class="btn ghost" id="cancel">Cancelar</button></div></form></div>`;
        body.querySelector('#cancel').onclick = draw;
        body.querySelector('#pf').onsubmit = async e => { e.preventDefault(); const v = id => body.querySelector('#' + id).value.trim();
          if (p) Object.assign(p, { name: v('name'), birth: v('birth'), guardian: v('guardian') });
          else { const n = { id: 'p' + Date.now(), name: v('name'), birth: v('birth'), guardian: v('guardian'), history: [{ at: new Date().toISOString(), type: 'cadastro', text: 'Paciente cadastrado' }] }; D.patients.push(n); sel = n.id; }
          await save(); draw(); };
      };
      draw();
    }
  };
})();
