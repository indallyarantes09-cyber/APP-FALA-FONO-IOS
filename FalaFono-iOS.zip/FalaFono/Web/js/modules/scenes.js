FF.modules.scenes = {
  title: 'Cenários 3D',
  mount(el) {
    const ar = FF.ar.available();
    el.innerHTML = `<h1>Cenário 3D</h1><p class="sub">Escolha um cenário. Explore com o mouse na tela ou use o Merge Cube com a webcam.</p>
    <div class="grid">
      ${[['house', '🏡', 'Minha casa', 'Sala, cozinha, quarto e banheiro com objetos interativos.', 'c1'], ['animals', '🌳', 'Floresta com Animais', 'Animais 3D animados e seus sons.', 'c3']].map(([id, ic, t, d, c]) => `
      <div class="mcard ${c}"><div class="ic">${ic}</div><h3>${t}</h3><p>${d}</p>
        <div class="row" style="margin-top:auto"><button class="btn ghost" data-go="${id}">🖥️ Explorar em 3D</button><button class="btn ghost" data-go="ar" data-params='{"content":"${id}"}'>🧊 Usar Merge Cube</button></div>
        <span class="badge">${ar ? '✅ RA disponível' : '⚠️ RA: rastreador não instalado'}</span></div>`).join('')}
    </div>`;
    FF.ui.guide('Escolha um cenário para explorar!');
  }
};
