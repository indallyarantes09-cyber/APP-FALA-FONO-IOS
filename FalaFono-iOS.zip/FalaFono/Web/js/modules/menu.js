FF.modules.menu = {
  title: 'Menu principal',
  mount(el) {
    const ar = FF.ar.available() ? '✅ RA disponível' : '⚠️ RA: rastreador não instalado';
    const mods = [['scenes', '🧊', 'Cenários 3D', 'Explore ambientes 3D com o mouse ou o Merge Cube.', 'c1', ar], ['house', '🏠', 'Minha Casa', 'Objetos da casa e seus nomes.', 'c2', ar], ['animals', '🐶', 'Animais e seus Sons', 'Clique nos animais para ouvir.', 'c3', ar], ['cards', '🃏', 'Criar Cards', 'Monte, salve e imprima cards.', 'c4'], ['clinical', '⭐', 'Área Clínica', 'Pacientes, sessões e registros (protegida por PIN).', 'c5'], ['settings', '⚙️', 'Configurações', 'Áudio, gráficos, webcam e acessibilidade.', 'c6']];
    el.innerHTML = `<h1>Papagaíto</h1><p class="sub">Escolha uma atividade.</p><div class="grid">${mods.map(([id, ic, t, d, c, b], i) => `<button class="mcard ${c}" data-go="${id}"><span class="ic">${ic}</span><h3>${i + 1}. ${t}</h3><p>${d}</p>${b ? `<span class="badge">${b}</span>` : ''}</button>`).join('')}</div>`;
    FF.ui.guide('Escolha uma atividade. Dica: teclas 1 a 6 abrem os módulos.');
    this.k = e => { if (e.target.matches('input,textarea,select')) return; const m = mods[+e.key - 1]; if (m) FF.router.go(m[0]); };
    addEventListener('keydown', this.k);
  },
  unmount() { removeEventListener('keydown', this.k); }
};
