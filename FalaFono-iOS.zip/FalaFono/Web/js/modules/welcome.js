FF.modules.welcome = {
  title: 'Início',
  mount(el) {
    el.innerHTML = `<div class="welcome">
      <div style="text-align:center"><img class="mascot" src="assets/characters/papagaito.png" alt="Papagaíto, mascote do Fala Fono"></div>
      <div><div class="bubble">Olá! Eu sou o Papagaíto!<br>Vamos aprender brincando?</div>
        <p class="biglogo"><span style="color:var(--laranja)">Fala</span> <span style="color:var(--amarelo)">Fono</span></p>
        <p class="sub">Atividades de fonoaudiologia com cenários 3D, sons e cards.</p>
        <div class="actions"><button class="btn" id="start" style="font-size:1.4rem">▶ Começar</button><button class="btn alt" data-go="clinical">Sou Fonoaudiólogo</button><button class="btn ghost" id="hello">🔊 Ouvir o Papagaíto</button></div>
        <div class="actions"><button class="btn ghost" data-go="scenes">Cenários 3D</button><button class="btn ghost" data-go="cards">Criar Cards</button><button class="btn ghost" data-go="settings">Configurações</button><button class="btn ghost" id="about">Sobre</button></div>
        <p id="abouttxt" class="sub" hidden>Fala Fono para iOS — versão 0.2.0. Recurso educativo de apoio; não realiza diagnóstico.</p>
      </div></div>`;
    document.getElementById('guide').classList.add('hidden');
    el.querySelector('#start').onclick = () => { FF.audio.sfx('ok'); FF.router.go('menu'); };
    el.querySelector('#hello').onclick = () => FF.audio.say('Olá! Eu sou o Papagaíto! Vamos aprender brincando?', { force: true });
    el.querySelector('#about').onclick = () => el.querySelector('#abouttxt').hidden ^= 1;
  },
  unmount() { document.getElementById('guide').classList.remove('hidden'); }
};
