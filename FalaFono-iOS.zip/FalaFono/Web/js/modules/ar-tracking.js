/* Merge Cube / Realidade Aumentada.
   IMPORTANTE: nenhum rastreador real do Merge Cube está incluído nesta base.
   A webcam funciona; o rastreamento depende de um provedor que implemente a interface abaixo:
     provider.init(videoEl) -> Promise
     provider.update() -> { found:boolean, matrix?: THREE.Matrix4 (pose do cubo em coords da câmera), fov?: number }
   Registre com FF.ar.registerProvider(provider). Ver README (seção Merge Cube). */
FF.ar = {
  provider: null,
  registerProvider(p) { this.provider = p; },
  available() { return !!this.provider; },
  statusLabel() { return this.provider ? 'RA disponível' : 'RA: rastreador não instalado'; }
};
FF.modules.ar = (() => {
  let stream = null, v = null, lostSince = 0, foundOnce = false;
  return {
    title: 'Merge Cube',
    async mount(el, params) {
      const content = params.content || 'house', C = FF.catalog;
      el.innerHTML = `
      <div class="topbar"><button class="btn ghost" id="back">⬅ Voltar</button><span class="pill">🧊 Usar Merge Cube</span></div>
      <div class="stage">
        <div class="ar-wrap viewport" id="arvp"><video id="cam" playsinline muted></video><div class="ar-status" id="st">Solicitando permissão para a webcam…</div></div>
        <div class="panel">
          <div class="chips"><button data-c="house" class="${content === 'house' ? 'sel' : ''}">🏠 Casa</button><button data-c="animals" class="${content === 'animals' ? 'sel' : ''}">🐶 Animais</button></div>
          <h3>Selecionar conteúdo</h3><div class="chips" id="items"></div>
          <div class="info" id="info">Posicione o Merge Cube diante da câmera.</div>
          <button class="btn" id="repeat">🔁 Repetir</button>
          <div class="warn" id="trk"></div>
          <button class="btn alt" id="fallback">🖥️ Explorar em 3D (sem cubo)</button>
        </div>
      </div>`;
      el.querySelector('#back').onclick = () => FF.router.back();
      el.querySelector('#fallback').onclick = () => FF.router.go(content === 'animals' ? 'animals' : 'house');
      el.querySelectorAll('[data-c]').forEach(b => b.onclick = () => FF.router.go('ar', { content: b.dataset.c }, false));
      const st = el.querySelector('#st'), trk = el.querySelector('#trk'), info = el.querySelector('#info');
      const list = content === 'animals' ? C.animals.slice(0, 4) : (C.rooms.find(r => r.id === params.room) || C.rooms[0]).items;
      el.querySelector('#items').innerHTML = list.map(i => `<button data-id="${i.id}">${i.emoji} ${i.word}</button>`).join('');
      trk.innerHTML = FF.ar.available() ? '✅ Rastreador de cubo carregado.' :
        '<b>Rastreamento do Merge Cube não instalado.</b><br>A câmera funciona, mas o cubo ainda não é detectado. Esta base não simula o rastreamento. Veja o README para integrar o SDK.';
      // Webcam
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw Object.assign(new Error(), { name: 'NotSupported' });
        const camId = FF.store.settings().cameraId;
        stream = await navigator.mediaDevices.getUserMedia({ video: camId ? { deviceId: { exact: camId } } : { width: 1280, height: 720 } });
        const vid = el.querySelector('#cam'); vid.srcObject = stream; await vid.play();
        st.textContent = 'Câmera ativa. Posicione o Merge Cube diante da câmera.'; FF.ui.guide('Posicione o Merge Cube diante da câmera.', true);
      } catch (e) {
        const msg = { NotAllowedError: 'Permissão de câmera negada. Libere a câmera nas configurações de privacidade do Windows.', NotFoundError: 'Nenhuma webcam encontrada.', NotReadableError: 'A webcam está em uso por outro programa.' }[e.name] || 'Webcam indisponível.';
        st.innerHTML = `⚠️ ${msg}<br><button class="btn" onclick="FF.router.go('${content === 'animals' ? 'animals' : 'house'}')">Voltar ao modo 3D convencional</button>`;
        return;
      }
      // Camada 3D sobre o vídeo (mesmos modelos do modo convencional)
      const anchor = new THREE.Group();
      v = new FF.Viewer(el.querySelector('#arvp'), {
        transparent: true, onSelect: d => { info.innerHTML = `<b style="font-size:1.4rem">${d.word}</b>`; FF.audio.say(content === 'animals' ? { text: d.word + '! ' + d.sound, file: C.audioFile('animals', d.id) } : { text: d.word, file: C.audioFile('words', d.id) }, { force: true }); el.querySelectorAll('#items button').forEach(b => b.classList.toggle('sel', b.dataset.id === d.id)); },
        beforeRender: (vw) => {
          if (!FF.ar.provider) return;
          const r = FF.ar.provider.update();
          if (r && r.found) { anchor.visible = true; anchor.matrixAutoUpdate = false; anchor.matrix.copy(r.matrix); vw.camera.position.set(0, 0, 0); vw.camera.lookAt(0, 0, -1); if (r.fov) { vw.camera.fov = r.fov; vw.camera.updateProjectionMatrix(); } if (!foundOnce || lostSince) st.textContent = 'Cubo detectado! Gire o cubo para ver de outros ângulos.'; foundOnce = true; lostSince = 0; }
          else { anchor.visible = false; if (!lostSince) { lostSince = performance.now(); st.textContent = 'Procurando o cubo…'; } else if (performance.now() - lostSince > 2500 && st.dataset.warned !== '1') { st.dataset.warned = '1'; st.textContent = 'Não consegui encontrar o cubo. Tente posicioná-lo novamente.'; FF.ui.guide(st.textContent, true); } }
        }
      });
      v.root.add(anchor);
      // Conteúdo sobre o cubo (escala: aresta do cubo = 1 unidade)
      list.forEach((d, i) => { const m = FF.models.build(d.model); m.scale.setScalar(content === 'animals' ? .35 : .3); v.add(m, Object.assign({}, d, { pos: [((i % 2) - .5) * .5, .5, (Math.floor(i / 2) - .5) * .5] })); anchor.add(m); });
      v.root.children.filter(c => c !== anchor && c.userData.item).forEach(c => anchor.add(c));
      anchor.visible = false; // sem rastreador nada é desenhado: não há simulação
      el.querySelector('#items').onclick = e => { const b = e.target.closest('button'); if (b) v.select(b.dataset.id, true); };
      el.querySelector('#repeat').onclick = () => FF.audio.repeat();
      if (FF.ar.provider) { try { await FF.ar.provider.init(el.querySelector('#cam')); } catch (e) { trk.textContent = 'Falha ao iniciar o rastreador: ' + e.message; } }
    },
    unmount() { stream && stream.getTracks().forEach(t => t.stop()); stream = null; v && v.dispose(); v = null; lostSince = 0; foundOnce = false; }
  };
})();
