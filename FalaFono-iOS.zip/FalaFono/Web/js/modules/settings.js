FF.modules.settings = {
  title: 'Configurações',
  async mount(el) {
    const s = FF.store.settings();
    el.innerHTML = `<div class="topbar"><button class="btn ghost" id="back">⬅ Voltar</button><h1 style="margin:0">Configurações</h1></div>
    <div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(320px,1fr))">
      <div class="card-box"><h2>🔊 Áudio</h2>
        <label>Volume <input type="range" id="volume" min="0" max="1" step=".05" value="${s.volume}"></label>
        <label>Velocidade da fala <input type="range" id="rate" min=".6" max="1.3" step=".05" value="${s.rate}"></label>
        <label style="flex-direction:row"><input type="checkbox" id="narration" ${s.narration ? 'checked' : ''}> Narração e instruções</label>
        <label style="flex-direction:row"><input type="checkbox" id="sfx" ${s.sfx ? 'checked' : ''}> Efeitos sonoros da interface</label>
        <button class="btn" id="test">Testar voz</button></div>
      <div class="card-box"><h2>🎨 Gráficos</h2>
        <label>Qualidade 3D<select id="quality"><option value="baixa">Baixa (PCs simples)</option><option value="media">Média</option><option value="alta">Alta</option></select></label>
        <label style="flex-direction:row"><input type="checkbox" id="reduceMotion" ${s.reduceMotion ? 'checked' : ''}> Reduzir animações</label>
        <label>Tamanho do texto <input type="range" id="fontScale" min=".9" max="1.4" step=".05" value="${s.fontScale}"></label>
        <label style="flex-direction:row"><input type="checkbox" id="guide" ${s.guide ? 'checked' : ''}> Mostrar o Papagaíto guia</label></div>
      <div class="card-box"><h2>📷 Webcam</h2><label>Câmera<select id="cameraId"><option value="">Padrão do sistema</option></select></label><p class="sub">Os nomes das câmeras aparecem após a primeira permissão de acesso.</p></div>
      <div class="card-box"><h2>💾 Dados</h2><button class="btn ghost" id="reset">Restaurar configurações padrão</button></div>
    </div>`;
    el.querySelector('#quality').value = s.quality;
    try { (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === 'videoinput').forEach((d, i) => el.querySelector('#cameraId').add(new Option(d.label || 'Câmera ' + (i + 1), d.deviceId))); el.querySelector('#cameraId').value = s.cameraId; } catch (e) { }
    el.oninput = el.onchange = e => { const t = e.target; if (!t.id || !(t.id in s)) return; s[t.id] = t.type === 'checkbox' ? t.checked : t.type === 'range' ? +t.value : t.value; FF.store.saveSettings(s); };
    el.querySelector('#test').onclick = () => FF.audio.say('Olá! Eu sou o Papagaíto!', { force: true });
    el.querySelector('#reset').onclick = () => { FF.store.remove('settings'); FF.applySettings(); FF.router.go('settings', {}, false); };
    el.querySelector('#back').onclick = () => FF.router.back();
  }
};
