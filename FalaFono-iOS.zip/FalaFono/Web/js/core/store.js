/* Persistência local: SQLite no Electron e localStorage no navegador. */
window.FF = window.FF || {};
FF.store = {
  prefix: 'falafono.',
  get(key, fallback) {
    try {
      if (window.ffHost) {
        const stored = window.ffHost.get(key);
        if (stored != null) return JSON.parse(stored);
        const legacy = localStorage.getItem(this.prefix + key);
        if (legacy != null) { if (window.ffHost.set(key, legacy)) localStorage.removeItem(this.prefix + key); return JSON.parse(legacy); }
        return fallback;
      }
      const v = localStorage.getItem(this.prefix + key); return v == null ? fallback : JSON.parse(v);
    } catch (e) { console.warn('Dado inválido em', key, e); return fallback; }
  },
  set(key, value) {
    try {
      const encoded = JSON.stringify(value);
      if (window.ffHost) { const ok = window.ffHost.set(key, encoded); if (!ok) throw new Error('SQLite indisponível'); return true; }
      localStorage.setItem(this.prefix + key, encoded); return true;
    } catch (e) { FF.ui && FF.ui.toast('Não foi possível salvar (' + e.name + ').'); return false; }
  },
  remove(key) { if (window.ffHost) window.ffHost.remove(key); else localStorage.removeItem(this.prefix + key); },
  defaults: { volume: 0.9, narration: true, sfx: true, rate: 0.9, quality: 'media', reduceMotion: false, fontScale: 1, guide: true, cameraId: '' },
  settings() { return Object.assign({}, this.defaults, this.get('settings', {})); },
  saveSettings(s) { this.set('settings', s); FF.applySettings && FF.applySettings(); },
  crypto: {
    async key(pin, salt) {
      const base = await crypto.subtle.importKey('raw', new TextEncoder().encode(pin), 'PBKDF2', false, ['deriveKey']);
      return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 150000, hash: 'SHA-256' }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
    },
    b64(buf) { return btoa(String.fromCharCode(...new Uint8Array(buf))); },
    unb64(s) { return Uint8Array.from(atob(s), c => c.charCodeAt(0)); },
    async encrypt(key, obj) {
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, new TextEncoder().encode(JSON.stringify(obj)));
      return { iv: this.b64(iv), ct: this.b64(ct) };
    },
    async decrypt(key, box) {
      const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: this.unb64(box.iv) }, key, this.unb64(box.ct));
      return JSON.parse(new TextDecoder().decode(pt));
    }
  }
};
