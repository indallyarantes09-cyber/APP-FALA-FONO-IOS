/* Sistema central de áudio: um canal de fala (interrompe o anterior), efeitos separados.
   Ordem: arquivo gravado (assets/audio/...) -> síntese de voz pt-BR offline do sistema. */
FF.audio = (() => {
  let current = null, ctx = null, lastItem = null;
  const S = () => FF.store.settings();
  function voice() {
    const vs = speechSynthesis.getVoices();
    return vs.find(v => /pt-BR/i.test(v.lang) && v.localService) || vs.find(v => /pt[-_]BR/i.test(v.lang)) || vs.find(v => /^pt/i.test(v.lang));
  }
  function stop() {
    if (current) { current.pause(); current = null; }
    if ('speechSynthesis' in window) speechSynthesis.cancel();
    if (window.falafonoNative && window.webkit?.messageHandlers?.falaFonoSpeech) {
      window.webkit.messageHandlers.falaFonoSpeech.postMessage({ action: 'stop' });
    }
  }
  function tts(text, rate) {
    return new Promise(res => {
      if (window.falafonoNative && window.webkit?.messageHandlers?.falaFonoSpeech) {
        window.webkit.messageHandlers.falaFonoSpeech.postMessage({
          action: 'speak', text: String(text), rate: rate || S().rate, volume: S().volume
        });
        res();
        return;
      }
      if (!('speechSynthesis' in window)) { FF.ui.toast('Síntese de voz indisponível neste sistema.'); return res(); }
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'pt-BR'; const v = voice(); if (v) u.voice = v;
      u.rate = rate || S().rate; u.volume = S().volume; u.onend = u.onerror = res;
      speechSynthesis.speak(u);
    });
  }
  function file(src) {
    return new Promise((res, rej) => {
      const a = new Audio(src); a.volume = S().volume; current = a;
      a.onended = res; a.onerror = () => rej(new Error('missing'));
      a.play().catch(rej);
    });
  }
  /* item: {text, file?} — file é opcional; se ausente/quebrado, cai para TTS sem travar */
  async function say(item, opts = {}) {
    if (typeof item === 'string') item = { text: item };
    if (!opts.force && !S().narration) return;
    stop(); lastItem = item;
    if (item.file) { try { await file(item.file); return; } catch (e) { console.info('Áudio ausente, usando voz sintética:', item.file); } }
    await tts(item.text, opts.rate);
  }
  function sfx(type) {
    if (!S().sfx) return;
    try {
      ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
      const o = ctx.createOscillator(), g = ctx.createGain(); o.connect(g); g.connect(ctx.destination);
      const t = ctx.currentTime, f = { click: [660, 880], ok: [523, 1046], err: [300, 180] }[type] || [600, 700];
      o.frequency.setValueAtTime(f[0], t); o.frequency.exponentialRampToValueAtTime(f[1], t + .12);
      g.gain.setValueAtTime(.08 * S().volume, t); g.gain.exponentialRampToValueAtTime(.0001, t + .2);
      o.start(t); o.stop(t + .22);
    } catch (e) { /* sem áudio: ignora */ }
  }
  if ('speechSynthesis' in window) speechSynthesis.onvoiceschanged = () => {};
  return { say, stop, sfx, repeat: () => lastItem && say(lastItem, { force: true }) };
})();
