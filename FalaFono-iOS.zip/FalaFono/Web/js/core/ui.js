FF.ui = {
  h(html) { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; },
  esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); },
  toast(msg, ms = 2600) { const t = document.getElementById('toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove('show'), ms); },
  /* Papagaíto guia: mensagem curta, fala opcional */
  guide(msg, speak = false) {
    const g = document.getElementById('guide'), b = document.getElementById('guide-bubble');
    if (!FF.store.settings().guide) { g.classList.add('hidden'); return; }
    g.classList.remove('hidden'); b.textContent = msg; g.classList.add('show');
    clearTimeout(g._h); g._h = setTimeout(() => g.classList.remove('show'), 6000);
    if (speak) FF.audio.say(msg);
  },
  /* Executa um módulo isolando erros para não derrubar o app */
  safe(fn, where) { try { return fn(); } catch (e) { console.error(e); FF.ui.errorBox(where, e); } },
  errorBox(where, e) {
    const v = document.getElementById('view');
    v.innerHTML = `<div class="warn"><h2>Ops! Algo deu errado em ${FF.ui.esc(where)}.</h2><p>${FF.ui.esc(e.message || e)}</p><button class="btn" data-go="menu">Voltar ao menu</button></div>`;
  }
};
