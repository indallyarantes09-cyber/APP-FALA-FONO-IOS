/* Navegação simples por rotas; cada módulo registra {title, mount(el, params), unmount()} */
FF.modules = {};
FF.router = {
  current: null, history: [],
  go(name, params = {}, push = true) {
    const mod = FF.modules[name]; if (!mod) return FF.ui.toast('Módulo não encontrado: ' + name);
    if (this.current && this.current.mod.unmount) FF.ui.safe(() => this.current.mod.unmount(), 'saída do módulo');
    FF.audio.stop();
    if (push && this.current) this.history.push(this.current);
    this.current = { name, params, mod };
    const view = document.getElementById('view'); view.innerHTML = ''; view.scrollTop = 0;
    document.getElementById('sidebar').hidden = name === 'welcome';
    document.querySelectorAll('nav button').forEach(b => b.classList.toggle('active', b.dataset.go === name));
    FF.ui.safe(() => mod.mount(view, params), mod.title || name);
  },
  back() { const p = this.history.pop(); if (p) this.go(p.name, p.params, false); else this.go('menu', {}, false); }
};
document.addEventListener('click', e => {
  const b = e.target.closest('[data-go]'); if (!b) return;
  FF.audio.sfx('click'); FF.router.go(b.dataset.go, b.dataset.params ? JSON.parse(b.dataset.params) : {});
});
