import SwiftUI

@main
struct FalaFonoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
