import SwiftUI
import UIKit

struct ShareDocument: Identifiable {
    let id = UUID()
    let url: URL
}

struct PrintRequest: Identifiable {
    let id = UUID()
    let cards: [PrintableCard]
}

private enum ActiveSheet: Identifiable {
    case share(ShareDocument)
    case print(PrintRequest)

    var id: UUID {
        switch self {
        case .share(let document): document.id
        case .print(let request): request.id
        }
    }
}

struct ContentView: View {
    @State private var activeSheet: ActiveSheet?

    var body: some View {
        FalaFonoWebView(
            onShare: { activeSheet = .share(ShareDocument(url: $0)) },
            onPrint: { activeSheet = .print(PrintRequest(cards: $0)) }
        )
        .preferredColorScheme(.light)
        .sheet(item: $activeSheet) { sheet in
            switch sheet {
            case .share(let document):
                ActivitySheet(items: [document.url])
            case .print(let request):
                PrintCardsSheet(cards: request.cards) { activeSheet = nil }
            }
        }
    }
}

private struct ActivitySheet: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
