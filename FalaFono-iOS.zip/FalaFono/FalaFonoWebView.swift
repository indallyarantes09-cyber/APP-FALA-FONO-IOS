import AVFoundation
import SwiftUI
import UIKit
import WebKit

struct FalaFonoWebView: UIViewRepresentable {
    let onShare: (URL) -> Void
    let onPrint: ([PrintableCard]) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onShare: onShare, onPrint: onPrint)
    }

    func makeUIView(context: Context) -> WKWebView {
        let contentController = WKUserContentController()
        let script = WKUserScript(
            source: "window.falafonoNative = true;",
            injectionTime: .atDocumentStart,
            forMainFrameOnly: true
        )
        contentController.addUserScript(script)
        contentController.add(context.coordinator, name: "falaFonoSpeech")
        contentController.add(context.coordinator, name: "falaFonoExport")
        contentController.add(context.coordinator, name: "falaFonoPrint")

        let configuration = WKWebViewConfiguration()
        configuration.userContentController = contentController
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 0.35, green: 0.23, blue: 0.62, alpha: 1)
        webView.scrollView.backgroundColor = webView.backgroundColor
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.allowsBackForwardNavigationGestures = false

        if let webRoot = Bundle.main.resourceURL?.appendingPathComponent("Web", isDirectory: true),
           let indexURL = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "Web") {
            webView.loadFileURL(indexURL, allowingReadAccessTo: webRoot)
        } else {
            webView.loadHTMLString(
                "<meta name='viewport' content='width=device-width, initial-scale=1'><p>Não foi possível abrir os arquivos do Fala Fono.</p>",
                baseURL: nil
            )
        }

        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {}

    @MainActor
    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {
        private let onShare: (URL) -> Void
        private let onPrint: ([PrintableCard]) -> Void
        private let synthesizer = AVSpeechSynthesizer()

        init(onShare: @escaping (URL) -> Void, onPrint: @escaping ([PrintableCard]) -> Void) {
            self.onShare = onShare
            self.onPrint = onPrint
        }

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard let body = message.body as? [String: Any] else { return }

            switch message.name {
            case "falaFonoSpeech":
                handleSpeech(body)
            case "falaFonoExport":
                guard let url = writeExport(body) else { return }
                onShare(url)
            case "falaFonoPrint":
                guard let rawCards = body["cards"],
                      let data = try? JSONSerialization.data(withJSONObject: rawCards),
                      let cards = try? JSONDecoder().decode([PrintableCard].self, from: data) else { return }
                onPrint(cards)
            default:
                break
            }
        }

        private func handleSpeech(_ message: [String: Any]) {
            let action = message["action"] as? String ?? ""
            if action == "stop" {
                synthesizer.stopSpeaking(at: .immediate)
                return
            }

            guard action == "speak", let text = message["text"] as? String, !text.isEmpty else { return }
            synthesizer.stopSpeaking(at: .immediate)

            let utterance = AVSpeechUtterance(string: text)
            utterance.voice = AVSpeechSynthesisVoice(language: "pt-BR")
            let requestedRate = (message["rate"] as? NSNumber)?.floatValue ?? 0.9
            utterance.rate = min(
                max(AVSpeechUtteranceDefaultSpeechRate * requestedRate, AVSpeechUtteranceMinimumSpeechRate),
                AVSpeechUtteranceMaximumSpeechRate
            )
            utterance.volume = min(max((message["volume"] as? NSNumber)?.floatValue ?? 0.9, 0), 1)
            synthesizer.speak(utterance)
        }

        private func writeExport(_ message: [String: Any]) -> URL? {
            guard let content = message["content"] as? String,
                  let data = content.data(using: .utf8) else { return nil }
            let requestedName = message["filename"] as? String ?? "falafono-export.json"
            let safeName = URL(fileURLWithPath: requestedName).lastPathComponent
                .replacingOccurrences(of: "..", with: "_")
            let url = FileManager.default.temporaryDirectory.appendingPathComponent(safeName)
            do {
                try data.write(to: url, options: .atomic)
                return url
            } catch {
                return nil
            }
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else {
                decisionHandler(.cancel)
                return
            }
            if url.isFileURL || url.scheme == "about" || url.scheme == "blob" {
                decisionHandler(.allow)
            } else {
                // O app funciona offline; links externos não são carregados dentro do app.
                decisionHandler(.cancel)
            }
        }

        func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
            let alert = UIAlertController(title: "Fala Fono", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
            present(alert, from: webView)
        }

        func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
            let alert = UIAlertController(title: "Fala Fono", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Cancelar", style: .cancel) { _ in completionHandler(false) })
            alert.addAction(UIAlertAction(title: "Continuar", style: .destructive) { _ in completionHandler(true) })
            present(alert, from: webView)
        }

        func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
            let alert = UIAlertController(title: "Fala Fono", message: prompt, preferredStyle: .alert)
            alert.addTextField { $0.text = defaultText }
            alert.addAction(UIAlertAction(title: "Cancelar", style: .cancel) { _ in completionHandler(nil) })
            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(alert.textFields?.first?.text) })
            present(alert, from: webView)
        }

        private func present(_ alert: UIAlertController, from webView: WKWebView) {
            guard var presenter = webView.window?.rootViewController else { return }
            while let next = presenter.presentedViewController { presenter = next }
            presenter.present(alert, animated: true)
        }
    }
}

struct PrintableCard: Decodable, Identifiable {
    let id: String
    let emoji: String?
    let word: String
    let phrase: String?
    let template: String?
    let color: String?
    let textColor: String?
    let size: Double?
    let image: String?
}

struct PrintCardsSheet: UIViewControllerRepresentable {
    let cards: [PrintableCard]
    let onDone: () -> Void

    func makeUIViewController(context: Context) -> PrintPresenterController {
        PrintPresenterController(pdfData: makePDF(cards), onDone: onDone)
    }

    func updateUIViewController(_ controller: PrintPresenterController, context: Context) {}

    private func makePDF(_ cards: [PrintableCard]) -> Data {
        let page = CGRect(x: 0, y: 0, width: 595, height: 842)
        let renderer = UIGraphicsPDFRenderer(bounds: page)
        return renderer.pdfData { context in
            let margin: CGFloat = 32
            let gap: CGFloat = 18
            let columns = 2
            let rows = 3
            let cardWidth = (page.width - margin * 2 - gap) / CGFloat(columns)
            let cardHeight = (page.height - margin * 2 - gap * CGFloat(rows - 1)) / CGFloat(rows)

            for pageStart in stride(from: 0, to: max(cards.count, 1), by: columns * rows) {
                context.beginPage()
                let pageCards = Array(cards.dropFirst(pageStart).prefix(columns * rows))
                for (index, card) in pageCards.enumerated() {
                    let column = index % columns
                    let row = index / columns
                    let rect = CGRect(
                        x: margin + CGFloat(column) * (cardWidth + gap),
                        y: margin + CGFloat(row) * (cardHeight + gap),
                        width: cardWidth,
                        height: cardHeight
                    ).insetBy(dx: 3, dy: 3)
                    draw(card, in: rect)
                }
            }
        }
    }

    private func draw(_ card: PrintableCard, in rect: CGRect) {
        let background: UIColor
        if card.template == "solido" {
            background = UIColor(hex: card.color)
        } else if card.template == "moldura" {
            background = .white
        } else {
            background = UIColor(hex: "#F8D55A")
        }
        let border = UIColor(hex: card.template == "classico" ? "#E9A23B" : (card.color ?? "#E9A23B"))
        let shape = UIBezierPath(roundedRect: rect, cornerRadius: 14)
        background.setFill()
        shape.fill()
        border.setStroke()
        shape.lineWidth = card.template == "moldura" ? 4 : 2
        shape.stroke()

        let imageRect = CGRect(x: rect.minX + 16, y: rect.minY + 16, width: rect.width - 32, height: rect.height * 0.48)
        if let dataURL = card.image, let comma = dataURL.firstIndex(of: ","),
           let bytes = Data(base64Encoded: String(dataURL[dataURL.index(after: comma)...])),
           let image = UIImage(data: bytes) {
            image.draw(in: imageRect)
        } else {
            let symbol = card.emoji ?? "❓"
            (symbol as NSString).draw(in: imageRect, withAttributes: [
                .font: UIFont.systemFont(ofSize: 82),
                .paragraphStyle: centeredParagraph()
            ])
        }

        let titleRect = CGRect(x: rect.minX + 12, y: imageRect.maxY + 4, width: rect.width - 24, height: 50)
        (card.word as NSString).draw(in: titleRect, withAttributes: [
            .font: UIFont.boldSystemFont(ofSize: CGFloat(min(max(card.size ?? 26, 16), 36))),
            .foregroundColor: UIColor(hex: card.textColor ?? "#3B2A00"),
            .paragraphStyle: centeredParagraph()
        ])
        if let phrase = card.phrase, !phrase.isEmpty {
            let phraseRect = CGRect(x: rect.minX + 16, y: titleRect.maxY + 3, width: rect.width - 32, height: rect.maxY - titleRect.maxY - 18)
            (phrase as NSString).draw(in: phraseRect, withAttributes: [
                .font: UIFont.systemFont(ofSize: 13),
                .foregroundColor: UIColor(hex: card.textColor ?? "#3B2A00"),
                .paragraphStyle: centeredParagraph()
            ])
        }
    }

    private func centeredParagraph() -> NSMutableParagraphStyle {
        let style = NSMutableParagraphStyle()
        style.alignment = .center
        style.lineBreakMode = .byWordWrapping
        return style
    }
}

final class PrintPresenterController: UIViewController {
    private let pdfData: Data
    private let onDone: () -> Void
    private var hasPresented = false

    init(pdfData: Data, onDone: @escaping () -> Void) {
        self.pdfData = pdfData
        self.onDone = onDone
        super.init(nibName: nil, bundle: nil)
        view.backgroundColor = .systemBackground
    }

    required init?(coder: NSCoder) {
        return nil
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        guard !hasPresented else { return }
        hasPresented = true
        let printController = UIPrintInteractionController.shared
        printController.printingItem = pdfData
        let completion: UIPrintInteractionController.CompletionHandler = { [onDone] _, _, _ in
            onDone()
        }
        if UIDevice.current.userInterfaceIdiom == .pad {
            printController.present(from: view.bounds, in: view, animated: true, completionHandler: completion)
        } else {
            printController.present(animated: true, completionHandler: completion)
        }
    }
}

private extension UIColor {
    convenience init(hex: String?) {
        let cleaned = (hex ?? "#5A3A9E").trimmingCharacters(in: CharacterSet(charactersIn: "#"))
        let value = UInt64(cleaned, radix: 16) ?? 0x5A3A9E
        self.init(
            red: CGFloat((value >> 16) & 0xFF) / 255,
            green: CGFloat((value >> 8) & 0xFF) / 255,
            blue: CGFloat(value & 0xFF) / 255,
            alpha: 1
        )
    }
}
